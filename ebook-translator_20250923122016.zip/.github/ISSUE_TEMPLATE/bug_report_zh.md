---
name: 错误报告
about: 创建一个报告以帮助我们改善
title: "[错误报告] 这里是你简洁的标题"
labels: ''
assignees: ''

---

**基础信息**

* 操作系统: **Windows/macOS/Linux 发行版**
* Calibre 版本: **x.x.x**
* 插件版本：**x.x.x**
* 插件来源: **安装自 Calibre/Rolling Release**

**描述错误**
清晰而简洁地描述你所遇到的错误

**期待变化**
清晰而简洁地描述你想要什么改变

**屏幕截图**
添加合适的截图来帮助你解释问题
